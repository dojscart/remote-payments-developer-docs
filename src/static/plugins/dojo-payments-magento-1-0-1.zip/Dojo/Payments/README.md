Dojo Module for Magento 2 Open Source
=====================================

Payment module for Magento 2 Open Source, allowing you to take payments via Dojo.

Requirements
------------

* Magento Open Source version 2.3.x or 2.4.x (tested up to 2.4.1)

Installation of the Dojo module
-------------------------------

1. Upload the contents of the folder to ```app/code/Dojo/Payments/``` in the Magento root folder.

2. Enable the Dojo module.

    ```sh
    $ php bin/magento module:enable Dojo_Payments --clear-static-content
    ```

3. Update Magento.

    ```sh
    $ php bin/magento setup:upgrade
    ```

4. Deploy the static view files (if needed).

    ```sh
    $ php bin/magento setup:static-content:deploy
    ```

Configuration of the Dojo payment method
----------------------------------------

1. Login to the Magento admin panel and go to **Stores** -> **Configuration** -> **Sales** -> **Payment Methods**.

2. If the Dojo payment method does not appear in the list of the payment methods, go to 
  **System** -> **Cache Management** and clear the Magento cache by clicking on the **Flush Magento Cache** button.

3. Go to **Payment Methods** and click the **Configure** button next to the payment method **Dojo** to expand the configuration settings.

4. Set **Enabled** to **Yes**.

5. Set your "Gateway Username/URL" and "Gateway JWT".

6. Optionally, set the rest of the settings as per your needs.

7. Click the **Save Config** button.

Changelog
---------

## [1.0.1] - 2021-07-16
### Added
- metaData parameter for API requests

### Removed
- User-Agent header and userAgent parameter for API requests


## [1.0.0] - 2021-05-06
### Initial Release

Support
-------

[devsupport@dojo.tech](mailto:devsupport@dojo.tech)
