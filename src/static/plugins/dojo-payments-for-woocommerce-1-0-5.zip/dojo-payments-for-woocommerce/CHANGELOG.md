# Changelog
Dojo for WooCommerce


## [1.0.5] - 2021-09-17
### Changed
- "WC tested up to" tag to 5.6.0


## [1.0.4] - 2021-07-21
### Changed
- "Tested up to" tag to 5.8
- "WC tested up to" tag to 5.5.1


## [1.0.3] - 2021-07-08
### Added
- metaData parameter for API requests

### Removed
- User-Agent header and userAgent parameter for API requests


## [1.0.2] - 2021-06-01
### Changed
- "WC tested up to" tag to 5.3.0


## [1.0.1] - 2021-05-21
### Removed
- Comment about implementation of pre-authorisation support


## [1.0.0] - 2021-05-07
### Initial Release
