=== Dojo for WooCommerce ===

Contributors: dojo, alexanderkaltchev
Tags: dojo, payments, checkout, credit card
Requires at least: 5.0
Tested up to: 5.8
Stable tag: 1.0.5
Requires PHP: 7.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Extends WooCommerce, allowing you to take payments via Dojo.


== Description ==

Dojo for WooCommerce is a WordPress plugin, allowing you to take payments via Dojo.

= Support =

<a href="mailto:devsupport@dojo.tech">devsupport@dojo.tech</a>


== Minimum Requirements ==

* PHP version 7.0 or greater. An actively supported version is recommended.
* WordPress 5.0 or greater (tested up to 5.8.1)
* WooCommerce 4.0 or greater (tested up to 5.6.0)
* jQuery 1.12.4 or greater (part of WordPress core)
* PCI-certified server using SSL/TLS


== Installation ==

1. Login into the admin area of your WordPress website.

2. Go to "Plugins" -> "Add New".

3. Click "Upload Plugin" link at the top of the page.

4. Click "Browse" and choose to the plugin's zip file.

5. Click the "Install Now" button.

6. Wait while the plugin is uploaded to your server.

7. Click the "Activate" link associated with "Dojo for WooCommerce" plugin.


== Activation and configuration of the Dojo payment method ==

1. Go to "WooCommerce" -> "Settings" -> "Payments".

2. Click the "Manage" button for the "Dojo" payment method.

3. Check the "Enable Dojo" checkbox.

4. Set your "Gateway Username/URL" and "Gateway JWT".

5. Set the "Gateway Environment" to "Test" or "Production" based on whether you want to use the Test or the Production gateway environment.

6. Optionally, set the rest of the settings as per your needs.

7. Click the "Save changes" button.


== Changelog ==

## [1.0.5] - 2021-09-17
### Changed
- "WC tested up to" tag to 5.6.0
