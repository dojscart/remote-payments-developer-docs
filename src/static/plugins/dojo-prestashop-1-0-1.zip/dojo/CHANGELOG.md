# Changelog
Dojo Module for PrestaShop


## [1.0.1] - 2021-07-21
### Added
- metaData parameter for API requests

### Removed
- User-Agent header and userAgent parameter for API requests


## [1.0.0] - 2021-05-18
### Initial Release
