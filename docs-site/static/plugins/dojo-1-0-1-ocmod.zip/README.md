Dojo Extension for OpenCart
===========================

Payment extension for OpenCart 3, allowing you to take payments via Dojo.

Description
-----------

Payment extension for OpenCart 3 (tested up to 3.0.3.6), allowing you to take payments via Dojo.

Installation using Extension Installer
--------------------------------------

1. Login to the OpenCart Admin Panel
2. Go to Extensions -> Extensions Installer -> Upload to upload the extension's zip file
3. Go to Extensions -> Extensions -> Payments and click the "Install" button next to "Dojo"
4. Click the "Edit" button next to "Dojo" to configure the extension
5. Set "Extension Status" to "Enabled"
6. Set your "Gateway Username/URL" and "Gateway JWT"
7. Set the "Gateway Environment" to "Test" or "Production" based on whether you want to use the Test or the Production gateway environment
8. Optionally, set the rest of the settings as per your needs
9. Click the "Save" button

Manual installation
-------------------

1. Unzip the extension's file and upload the content of the upload folder to the root folder of your OpenCart
2. Login to the OpenCart Admin Panel
3. Go to Extensions -> Extensions -> Payments and click the "Install" button next to "Dojo"
4. Click the "Edit" button next to "Dojo" to configure the extension
5. Set "Extension Status" to "Enabled"
6. Set your "Gateway Username/URL" and "Gateway JWT"
7. Set the "Gateway Environment" to "Test" or "Production" based on whether you want to use the Test or the Production gateway environment
8. Optionally, set the rest of the settings as per your needs
9. Click the "Save" button

Changelog
---------

## [1.0.1] - 2021-07-29
### Added
- metaData parameter for API requests

### Removed
- User-Agent header and userAgent parameter for API requests


## [1.0.0] - 2021-05-31
### Initial Release

Support
-------

[devsupport@dojo.tech](mailto:devsupport@dojo.tech)
