<?php
/*
 * Copyright (C) 2021 Paymentsense Ltd.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * @author      Dojo
 * @copyright   2021 Paymentsense Ltd.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html
 */

/**
 * Front controller for Dojo
 */
class ControllerExtensionPaymentDojo extends Controller
{
	/**
	 * Content types of the output of the module information
	 */
	const TYPE_APPLICATION_JSON = 'application/json';
	const TYPE_TEXT_PLAIN       = 'text/plain';

	/**
	 * OpenCart front routes
	 */
	const ROUTE_CHECKOUT_CART     = 'checkout/cart';
	const ROUTE_CHECKOUT_SUCCESS  = 'checkout/success';
	const ROUTE_CUSTOMER_REDIRECT = 'extension/payment/dojo/customerredirect';

	/**
	 * Supported content types of the output of the module information
	 *
	 * @var array
	 */
	protected $content_types = array(
		'json' => self::TYPE_APPLICATION_JSON,
		'text' => self::TYPE_TEXT_PLAIN
	);

	/**
	 * Index action handler showing the payment form
	 *
	 * @return string
	 */
	public function index() {
		$this->load->language('extension/payment/dojo');
		$this->load->model('checkout/order');
		$this->load->model('extension/payment/dojo');
		list($error_message, $form_data, $order_id) = $this->model_extension_payment_dojo->getPaymentFormData();
		if ($error_message) {
			$data = array(
				'error_message'                 => json_encode($error_message),
				'title'                         => $this->getConfigValue('dojo_title'),
				'message'                       => '',
				'payment_details_amount'        => '',
				'payment_details_currency_code' => '',
				'payment_details_payment_token' => '',
				'return_url'                    => '',
				'client_js_url'                 => '',
				'button_confirm'                => $this->language->get('button_confirm')
			);
		} else {
			$data = array(
				'error_message'                 => '',
				'title'                         => $this->getConfigValue('dojo_title'),
				'message'                       => $this->getConfigValue('dojo_description'),
				'payment_details_amount'        => $form_data['amount'],
				'payment_details_currency_code' => $form_data['currency_code'],
				'payment_details_payment_token' => $form_data['access_token'],
				'return_url'                    => $this->getCustomerRedirectUrl($order_id),
				'client_js_url'                 => $this->model_extension_payment_dojo->getClientJsUrl(),
				'button_confirm'                => $this->language->get('button_confirm')
			);
		}
		return $this->load->view("extension/payment/dojo", $data);
	}

	/**
	 * Customer Redirect action handler handling redirection of the customer after completing the payment
	 */
	public function customerredirect() {
		$this->language->load('extension/payment/dojo');
		$this->load->model('extension/payment/dojo');

		$error_message = '';
		$session_data  = $this->session->data;
		$order_id      = isset($session_data['order_id'])
			? (string)$session_data['order_id']
			: $this->getHttpVar('order_id', ModelExtensionPaymentDojo::API_METHOD_GET);
		if ($order_id) {
			$access_token = $this->getHttpVar('accessToken');
			if (empty($access_token)) {
				$access_token = $this->getHttpVar('paymentToken');
			}
			try {
				$error_message = $this->model_extension_payment_dojo->processGatewayResponse($order_id, $access_token);
			} catch (Exception $exception) {
				$error_message = sprintf($this->language->get('error_exception'), $exception->getMessage());
			}
		}
		$this->session->data['error'] = $error_message ? $error_message : '';
		$route = $error_message ? self::ROUTE_CHECKOUT_CART : self::ROUTE_CHECKOUT_SUCCESS;
		$this->response->redirect($this->url->link($route, '', 'SSL'));
	}

	/**
	 * Module Information action handler
	 */
	public function info() {
		$this->load->model('extension/payment/dojo');
		$info = array(
			'Module Name'              => $this->model_extension_payment_dojo->getModuleName(),
			'Module Installed Version' => $this->model_extension_payment_dojo->getModuleInstalledVersion()
		);
		if ($this->getRequestParameter('extended_info', '') === 'true') {
			$extended_info = array(
				'OpenCart Version' => $this->model_extension_payment_dojo->getOpenCartVersion(),
				'PHP Version'      => $this->model_extension_payment_dojo->getPhpVersion()
			);
			$info = array_merge($info, $extended_info);
		}
		$this->outputInfo($info);
	}

	/**
	 * Checksums action handler
	 */
	public function checksums() {
		$info = array(
			'Checksums' => $this->getFileChecksums()
		);
		$this->outputInfo($info);
	}

	/**
	 * Gets the URL of the page where the customer will be redirected after completing the payment
	 *
	 * @param string $order_id Order ID
	 *
	 * @return string A string containing URL
	 */
	protected function getCustomerRedirectUrl($order_id) {
		return str_replace(
			'&amp;',
			'&',
			$this->url->link(self::ROUTE_CUSTOMER_REDIRECT, array('order_id' => $order_id), 'SSL'
			)
		);
	}

	/**
	 * Gets the value of a parameter from the extension configuration settings
	 *
	 * @param string      $key     Configuration key
	 * @param string|null $default Default value
	 *
	 * @return string|null
	 */
	protected function getConfigValue($key, $default = null) {
		$key = "payment_{$key}";
		$value = $this->config->get($key);
		if (is_null($value) && !is_null($default)) {
			$value = $default;
		}
		return $value;
	}

	/**
	 * Gets the value of an HTTP GET/POST parameter
	 *
	 * @param string      $parameter HTTP GET/POST parameter
	 * @param string|null $method    HTTP method
	 *
	 * @return mixed
	 */
	protected function getHttpVar($parameter, $method = null) {
		if (empty($method)) {
			$method = $this->request->server['REQUEST_METHOD'];
		}
		switch ($method) {
			case 'GET':
				return array_key_exists($parameter, $this->request->get)
					? $this->request->get[$parameter]
					: '';
			case 'POST':
				return array_key_exists($parameter, $this->request->post)
					? $this->request->post[$parameter]
					: '';
			default:
				return '';
		}
	}

	/**
	 * Gets the value of a parameter from the route
	 *
	 * @param string $parameter Parameter
	 * @param string $default   Default value
	 *
	 * @return string
	 */
	protected function getRequestParameter($parameter, $default = '') {
		$result = $default;
		if (isset($this->request->get['route'])) {
			$route = $this->request->get['route'];
			if (preg_match('#/' . $parameter .'/([a-z0-9]+)#i', $route, $matches)) {
				$result = $matches[1];
			}
		}
		return $result;
	}

	/**
	 * Converts an array to string
	 *
	 * @param array  $arr   An associative array
	 * @param string $ident Indentation
	 *
	 * @return string
	 */
	protected function convertArrayToString($arr, $ident = '') {
		$result         = '';
		$indent_pattern = '  ';
		foreach ($arr as $key => $value) {
			if ('' !== $result) {
				$result .= PHP_EOL;
			}
			if (is_array($value)) {
				$value = PHP_EOL . $this->convertArrayToString($value, $ident . $indent_pattern);
			}
			$result .= $ident . $key . ': ' . $value;
		}
		return $result;
	}

	/**
	 * Outputs plugin information
	 *
	 * @param array $info Module information
	 */
	protected function outputInfo($info) {
		$output       = $this->getRequestParameter('output', 'text');
		$content_type = array_key_exists($output, $this->content_types)
			? $this->content_types[ $output ]
			: self::TYPE_TEXT_PLAIN;

		switch ($content_type) {
			case self::TYPE_APPLICATION_JSON:
				$body = json_encode($info);
				break;
			case self::TYPE_TEXT_PLAIN:
			default:
				$body = $this->convertArrayToString($info);
				break;
		}

		@header('Cache-Control: max-age=0, must-revalidate, no-cache, no-store', true);
		@header('Pragma: no-cache', true);
		@header('Content-Type: ' . $content_type, true);
		echo $body;
		exit;
	}

	/**
	 * Gets file checksums
	 *
	 * @return array
	 */
	protected function getFileChecksums() {
		$result = array();
		$root_path = realpath(__DIR__ . '/../../../..');
		$file_list = $this->getHttpVar('data');
		if (is_array($file_list)) {
			foreach ($file_list as $key => $file) {
				$filename = $root_path . '/' . $file;
				$result[$key] = is_file($filename)
					? sha1_file($filename)
					: null;
			}
		}
		return $result;
	}
}
